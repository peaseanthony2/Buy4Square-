<?php
$host="localhost";
$user="root";
$password="";
$databasename="webcam";

$con=  mysqli_connect($host,$user,$password,$databasename);

?>
