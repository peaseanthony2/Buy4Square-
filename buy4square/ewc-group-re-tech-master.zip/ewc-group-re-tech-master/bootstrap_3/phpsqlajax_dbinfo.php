<?php
$host="localhost";
$username="antbusk_antbusk";
$password="window16";
$database="antbusk_nw_weed_source";
?>